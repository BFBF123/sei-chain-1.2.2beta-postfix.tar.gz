import { BasicAllowance } from "./module/types/cosmos/feegrant/v1beta1/feegrant";
import { PeriodicAllowance } from "./module/types/cosmos/feegrant/v1beta1/feegrant";
import { AllowedMsgAllowance } from "./module/types/cosmos/feegrant/v1beta1/feegrant";
import { Grant } from "./module/types/cosmos/feegrant/v1beta1/feegrant";
export { BasicAllowance, PeriodicAllowance, AllowedMsgAllowance, Grant };
declare const _default;
export default _default;
